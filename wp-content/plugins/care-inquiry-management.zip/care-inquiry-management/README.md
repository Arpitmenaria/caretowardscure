# Care Inquiry Management

**A WordPress plugin for managing appointment inquiries from the Care Towards Cure theme.**

## Overview

Care Inquiry Management is a custom WordPress plugin designed to handle appointment bookings and inquiries submitted through the Care Towards Cure theme. It provides:

- Custom post type for storing inquiries
- Admin interface for viewing and managing bookings
- Email notifications for admins and customers
- Status tracking for each inquiry
- Searchable and sortable inquiry list

## Features

✅ **Stores Appointment Inquiries**
- Patient name, phone number, email
- Appointment date and time
- Reason for visit / message

✅ **Admin Dashboard**
- View all inquiries in a dedicated admin section
- Edit and manage inquiry details
- Track inquiry status (New, Contacted, Confirmed, Completed, Cancelled)
- Search and filter inquiries

✅ **Email Notifications**
- Admin notifications when new inquiry is received
- Customer confirmation email with details
- Automatic email handling via WordPress mail function

✅ **User-Friendly Management**
- Sortable columns (phone, email, date, status)
- Color-coded status badges
- Quick inline editing
- Bulk actions support

## Installation

1. **Upload the plugin:**
   - Copy the `care-inquiry-management` folder to `/wp-content/plugins/`

2. **Activate the plugin:**
   - Go to WordPress Admin → Plugins
   - Find "Care Inquiry Management"
   - Click "Activate"

3. **Plugin automatically:**
   - Creates custom post type for inquiries
   - Hooks into the Care Towards Cure theme
   - Registers custom database tables

## Usage

### View Inquiries

1. Go to WordPress Admin Dashboard
2. Look for "Inquiries" in the left sidebar (with email icon)
3. View all appointment bookings submitted through the booking form

### Manage Inquiry Status

1. Click on an inquiry to open the editor
2. In the right sidebar, find "Inquiry Status" box
3. Change status from:
   - **New** → Initial inquiry received
   - **Contacted** → You've reached out to the patient
   - **Confirmed** → Appointment confirmed
   - **Completed** → Appointment completed
   - **Cancelled** → Appointment cancelled

### Edit Inquiry Details

All inquiry information can be edited:
- Patient Name
- Phone Number
- Email Address
- Appointment Date & Time
- Reason for Visit
- Status

### Delete Inquiries

Once resolved, you can delete inquiries:
1. Open the inquiry
2. Click "Move to Trash" at the bottom
3. Or bulk select multiple inquiries and delete

## Database Storage

The plugin stores inquiries as custom posts with metadata:

**Post Type:** `care_inquiry`

**Stored Meta Fields:**
- `_care_patient_name` - Patient's full name
- `_care_phone` - Phone number
- `_care_email` - Email address
- `_care_appointment_date` - Requested appointment date
- `_care_appointment_time` - Requested appointment time
- `_care_reason` - Reason for visit / message
- `_care_country_code` - Country code (default: +91 India)
- `_care_inquiry_status` - Current status
- `_care_inquiry_submitted_at` - When inquiry was submitted

## Email Notifications

### Admin Notification
When a new inquiry is received, the site admin receives an email with:
- Patient details (name, phone, email)
- Appointment details (date, time, reason)
- Direct link to manage the inquiry in WordPress admin

### Customer Confirmation
If a customer email is provided, they receive:
- Confirmation that their inquiry was received
- Thank you message
- Expectation that admin will contact within 24 hours
- Contact information

## Theme Integration

This plugin hooks into the Care Towards Cure theme via:

**Action Hook:** `care_save_inquiry`

The theme's appointment booking form automatically triggers this hook when submitted, passing inquiry data to the plugin for storage and processing.

## Requirements

- **WordPress:** 6.0 or higher
- **PHP:** 8.2 or higher
- **Care Towards Cure Theme:** Latest version

## Settings

Settings page available at: **Inquiries → Settings**

Currently displays:
- Plugin version
- Post type information
- Feature overview
- Usage instructions

## Troubleshooting

### Inquiries Not Being Saved?
1. Ensure the plugin is activated
2. Check that the theme's appointment form is properly configured
3. Verify PHP error logs for any issues

### Emails Not Sending?
1. WordPress uses the PHP `mail()` function by default
2. Check your hosting provider's mail configuration
3. Consider installing a SMTP plugin like WP Mail SMTP

### Admin Menu Not Showing?
1. Clear your browser cache
2. Deactivate and reactivate the plugin
3. Ensure you're logged in as an admin user

## Support & Development

**Plugin Version:** 1.0.0  
**License:** GPL v2 or later  
**Author:** Care Towards Cure  

For feature requests or bug reports, contact the theme author.

## File Structure

```
care-inquiry-management/
├── care-inquiry-management.php       # Main plugin file
├── README.md                         # This file
├── assets/
│   └── admin-style.css              # Admin styles
├── includes/
│   ├── class-inquiry-post-type.php  # Custom post type
│   ├── class-inquiry-handler.php    # Data handler
│   ├── class-inquiry-notifications.php  # Email notifications
│   └── class-inquiry-admin.php      # Admin functionality
└── languages/
    └── care-inquiry-management.pot  # Translation template
```

## Changelog

### Version 1.0.0 (Initial Release)
- Custom post type for inquiries
- Admin dashboard interface
- Email notifications (admin + customer)
- Status tracking
- Sortable columns
- Full WordPress integration

---

**Made with ❤️ for Care Towards Cure**
