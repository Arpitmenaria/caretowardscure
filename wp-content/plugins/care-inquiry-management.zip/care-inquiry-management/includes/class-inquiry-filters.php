<?php
/**
 * Care Inquiry Filters
 *
 * Handles search, filtering, and sorting of inquiries
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Filters
 *
 * Manages custom search and filter functionality for inquiries
 */
class Care_Inquiry_Filters {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'posts_where', array( $this, 'filter_inquiry_search' ), 10, 2 );
		add_filter( 'posts_join', array( $this, 'join_postmeta_table' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( $this, 'add_filter_controls' ), 10, 2 );
		add_filter( 'posts_orderby', array( $this, 'custom_orderby' ), 10, 2 );
		add_action( 'pre_get_posts', array( $this, 'handle_status_filter' ) );
	}

	/**
	 * Filter inquiry search across multiple fields
	 *
	 * @param string   $where WHERE clause
	 * @param WP_Query $query Query object
	 * @return string Modified WHERE clause
	 */
	public function filter_inquiry_search( string $where, $query ): string {
		global $wpdb;

		// Only apply to inquiry post type in admin
		if ( ! is_admin() || $query->get( 'post_type' ) !== $this->post_type ) {
			return $where;
		}

		// Get search string
		$search = $query->get( 's' );

		if ( empty( $search ) ) {
			return $where;
		}

		// Remove the default search clause if it exists
		$search_term = '%' . $wpdb->esc_like( $search ) . '%';

		// Build custom search clause for multiple fields
		$search_clause = $wpdb->prepare(
			"({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR ({$wpdb->postmeta}.meta_key = '_care_phone' AND {$wpdb->postmeta}.meta_value LIKE %s) OR ({$wpdb->postmeta}.meta_key = '_care_email' AND {$wpdb->postmeta}.meta_value LIKE %s))",
			$search_term,
			$search_term,
			$search_term,
			$search_term
		);

		// Replace the default WordPress search with our custom one
		$where = preg_replace( '/\(\s*' . preg_quote( $wpdb->posts ) . '\.post_title\s+LIKE\s+[\'"][^\'"]*["\']\s*\)/', $search_clause, $where );

		return $where;
	}

	/**
	 * Join postmeta table for meta value searches
	 *
	 * @param string   $join  JOIN clause
	 * @param WP_Query $query Query object
	 * @return string Modified JOIN clause
	 */
	public function join_postmeta_table( string $join, $query ): string {
		global $wpdb;

		if ( ! is_admin() || $query->get( 'post_type' ) !== $this->post_type ) {
			return $join;
		}

		// Check if we need to join postmeta (for search or meta_query)
		$needs_join = ! empty( $query->get( 's' ) ) || ! empty( $query->get( 'meta_query' ) );

		if ( $needs_join && false === strpos( $join, $wpdb->postmeta ) ) {
			$join .= " LEFT JOIN {$wpdb->postmeta} ON {$wpdb->posts}.ID = {$wpdb->postmeta}.post_id ";
		}

		return $join;
	}

	/**
	 * Add custom filter controls to list table
	 *
	 * @param string $post_type Post type
	 * @param string $which     Location (top or bottom)
	 */
	public function add_filter_controls( string $post_type, string $which ): void {
		if ( $post_type !== $this->post_type || 'top' !== $which ) {
			return;
		}

		// Remove WordPress default filters
		global $wp_query;
		$wp_query->query_vars['suppress_filters'] = false;

		global $wpdb;

		// Get current filter values
		$current_status = isset( $_GET['filter_status'] ) ? sanitize_text_field( wp_unslash( $_GET['filter_status'] ) ) : '';
		$current_date   = isset( $_GET['filter_date'] ) ? sanitize_text_field( wp_unslash( $_GET['filter_date'] ) ) : '';

		?>
		<div class="care-filter-bar">
			<!-- Status Filter -->
			<select name="filter_status" class="care-filter-select">
				<option value=""><?php esc_html_e( 'All', 'care-inquiry-management' ); ?></option>
				<option value="new" <?php selected( $current_status, 'new' ); ?>><?php esc_html_e( 'New', 'care-inquiry-management' ); ?></option>
			</select>

			<!-- Date Filter -->
			<select name="filter_date" class="care-filter-select">
				<option value=""><?php esc_html_e( 'All Dates', 'care-inquiry-management' ); ?></option>
				<option value="this_week" <?php selected( $current_date, 'this_week' ); ?>><?php esc_html_e( 'This Week', 'care-inquiry-management' ); ?></option>
				<option value="this_month" <?php selected( $current_date, 'this_month' ); ?>><?php esc_html_e( 'This Month', 'care-inquiry-management' ); ?></option>
			</select>
		</div>
		<?php
	}

	/**
	 * Custom orderby for sorting
	 *
	 * @param string   $orderby ORDER BY clause
	 * @param WP_Query $query   Query object
	 * @return string Modified ORDER BY clause
	 */
	public function custom_orderby( string $orderby, $query ): string {
		global $wpdb;

		if ( ! is_admin() || $query->get( 'post_type' ) !== $this->post_type ) {
			return $orderby;
		}

		$orderby_param = $query->get( 'orderby' );
		$order         = $query->get( 'order', 'DESC' );

		// Ensure order is uppercase
		$order = in_array( strtoupper( $order ), array( 'ASC', 'DESC' ), true ) ? strtoupper( $order ) : 'DESC';

		// Handle custom sortable columns - only modify if orderby is set
		if ( $orderby_param && false !== strpos( $orderby, $wpdb->posts ) ) {
			switch ( $orderby_param ) {
				case '_care_appointment_date':
					$orderby = "CAST({$wpdb->postmeta}.meta_value AS DATE) {$order}";
					break;
			}
		}

		return $orderby;
	}

	/**
	 * Handle status and date filters from URL parameters
	 *
	 * @param WP_Query $query Query object
	 */
	public function handle_status_filter( $query ): void {
		if ( ! is_admin() || $query->get( 'post_type' ) !== $this->post_type ) {
			return;
		}

		$status     = isset( $_GET['filter_status'] ) ? sanitize_text_field( wp_unslash( $_GET['filter_status'] ) ) : '';
		$date_range = isset( $_GET['filter_date'] ) ? sanitize_text_field( wp_unslash( $_GET['filter_date'] ) ) : '';

		// Handle status filter
		if ( ! empty( $status ) ) {
			$meta_query = $query->get( 'meta_query', array() );
			if ( ! is_array( $meta_query ) ) {
				$meta_query = array();
			}
			$meta_query[] = array(
				'key'   => '_care_inquiry_status',
				'value' => $status,
			);
			$query->set( 'meta_query', $meta_query );
		}

		// Handle date range filter
		if ( ! empty( $date_range ) ) {
			$today           = gmdate( 'Y-m-d', current_time( 'timestamp' ) );
			$start_of_week   = gmdate( 'Y-m-d', strtotime( 'Monday this week', current_time( 'timestamp' ) ) );
			$start_of_month  = gmdate( 'Y-m-01' );
			$start_of_year   = gmdate( 'Y-01-01' );

			$meta_query = $query->get( 'meta_query', array() );
			if ( ! is_array( $meta_query ) ) {
				$meta_query = array();
			}

			switch ( $date_range ) {
				case 'today':
					$meta_query[] = array(
						'key'     => '_care_appointment_date',
						'value'   => $today,
						'compare' => '=',
					);
					break;

				case 'this_week':
					$meta_query[] = array(
						'key'     => '_care_appointment_date',
						'value'   => array( $start_of_week, $today ),
						'compare' => 'BETWEEN',
						'type'    => 'DATE',
					);
					break;

				case 'this_month':
					$meta_query[] = array(
						'key'     => '_care_appointment_date',
						'value'   => array( $start_of_month, $today ),
						'compare' => 'BETWEEN',
						'type'    => 'DATE',
					);
					break;

				case 'this_year':
					$meta_query[] = array(
						'key'     => '_care_appointment_date',
						'value'   => array( $start_of_year, $today ),
						'compare' => 'BETWEEN',
						'type'    => 'DATE',
					);
					break;
			}

			$query->set( 'meta_query', $meta_query );
		}
	}
}
