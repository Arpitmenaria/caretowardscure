<?php
/**
 * Care Inquiry Admin Notice
 *
 * Displays admin notices for new inquiries
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Admin_Notice
 *
 * Manages admin notices for new inquiries
 */
class Care_Inquiry_Admin_Notice {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Notice option key
	 *
	 * @var string
	 */
	private string $notice_key = 'care_inquiry_new_notice_dismissed';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'admin_notices', array( $this, 'display_new_inquiry_notice' ) );
		add_action( 'wp_ajax_care_dismiss_inquiry_notice', array( $this, 'dismiss_notice' ) );
	}

	/**
	 * Display new inquiry notice
	 */
	public function display_new_inquiry_notice(): void {
		// Check user capability
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Check if notice is dismissed
		$user_id = get_current_user_id();
		if ( get_user_meta( $user_id, $this->notice_key, true ) ) {
			return;
		}

		// Get count of new inquiries
		$new_count = $this->get_new_inquiries_count();

		// Only show if there are new inquiries
		if ( $new_count <= 0 ) {
			return;
		}

		// Only show on relevant pages
		if ( ! $this->should_display_notice() ) {
			return;
		}

		$inquiries_url = admin_url( 'edit.php?post_type=' . $this->post_type );
		$nonce         = wp_create_nonce( 'care_dismiss_inquiry_notice' );

		?>
		<div class="care-admin-notice care-notice-alert" id="care-inquiry-notice-<?php echo esc_attr( $user_id ); ?>">
			<div class="care-notice-content">
				<div class="care-notice-icon">🔴</div>
				<div class="care-notice-text">
					<strong><?php esc_html_e( 'New Appointment Inquiries', 'care-inquiry-management' ); ?></strong>
					<p>
						<?php
						printf(
							/* translators: %d = number of new inquiries */
							esc_html(
								_n(
									'You have %d new appointment inquiry waiting for review.',
									'You have %d new appointment inquiries waiting for review.',
									$new_count,
									'care-inquiry-management'
								)
							),
							absint( $new_count )
						);
						?>
					</p>
				</div>
				<div class="care-notice-actions">
					<a href="<?php echo esc_url( $inquiries_url ); ?>" class="care-notice-button care-notice-primary">
						<?php esc_html_e( '👁️ View Inquiries', 'care-inquiry-management' ); ?>
					</a>
					<button type="button" class="care-notice-button care-notice-dismiss" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-user-id="<?php echo esc_attr( $user_id ); ?>">
						<?php esc_html_e( 'Dismiss', 'care-inquiry-management' ); ?>
					</button>
				</div>
			</div>
		</div>

		<?php
		// Enqueue script for dismiss functionality
		$this->enqueue_notice_script();
	}

	/**
	 * Get count of new inquiries
	 *
	 * @return int Count of new inquiries
	 */
	private function get_new_inquiries_count(): int {
		global $wpdb;

		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = %s AND pm.meta_value = %s",
				'_care_inquiry_status',
				$this->post_type,
				'publish',
				'new'
			)
		);

		return absint( $count );
	}

	/**
	 * Check if notice should be displayed on current page
	 *
	 * @return bool True if notice should be displayed
	 */
	private function should_display_notice(): bool {
		global $pagenow, $current_screen;

		// Show on dashboard
		if ( 'index.php' === $pagenow ) {
			return true;
		}

		// Show on inquiry admin pages
		if ( isset( $current_screen ) && $this->post_type === $current_screen->post_type ) {
			return true;
		}

		// Show on clinic dashboard
		if ( isset( $_GET['page'] ) && 'care-clinic-dashboard' === sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Enqueue notice dismiss script
	 */
	private function enqueue_notice_script(): void {
		wp_enqueue_script(
			'care-inquiry-notice',
			CARE_INQUIRY_URI . 'assets/admin-notice.js',
			array( 'jquery' ),
			CARE_INQUIRY_VERSION,
			true
		);

		wp_localize_script(
			'care-inquiry-notice',
			'careNoticeData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => 'care_dismiss_inquiry_notice',
			)
		);
	}

	/**
	 * Handle notice dismissal via AJAX
	 */
	public function dismiss_notice(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'care_dismiss_inquiry_notice' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'care-inquiry-management' ) ) );
		}

		// Check capability
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'care-inquiry-management' ) ) );
		}

		// Get user ID
		$user_id = get_current_user_id();

		// Set user meta to dismiss notice for 24 hours
		update_user_meta( $user_id, $this->notice_key, time() );

		wp_send_json_success( array( 'message' => __( 'Notice dismissed', 'care-inquiry-management' ) ) );
	}
}
