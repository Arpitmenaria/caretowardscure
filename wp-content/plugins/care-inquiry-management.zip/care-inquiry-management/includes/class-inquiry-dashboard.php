<?php
/**
 * Care Inquiry Dashboard
 *
 * Manages the clinic dashboard with inquiry statistics and overview
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Dashboard
 *
 * Creates and manages the clinic dashboard
 */
class Care_Inquiry_Dashboard {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Menu page slug
	 *
	 * @var string
	 */
	private string $menu_slug = 'care-clinic-dashboard';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_dashboard_menu' ), 5 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_dashboard_styles' ) );
	}

	/**
	 * Register dashboard menu
	 */
	public function register_dashboard_menu(): void {
		add_menu_page(
			__( 'Clinic Dashboard', 'care-inquiry-management' ),
			__( 'Clinic Dashboard', 'care-inquiry-management' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render_dashboard' ),
			'dashicons-chart-line',
			20
		);
	}

	/**
	 * Enqueue dashboard styles
	 */
	public function enqueue_dashboard_styles(): void {
		global $pagenow, $current_screen;

		// Only load on dashboard page
		if ( isset( $current_screen->id ) && false !== strpos( $current_screen->id, $this->menu_slug ) ) {
			wp_enqueue_style(
				'care-inquiry-dashboard',
				CARE_INQUIRY_URI . 'assets/admin-style.css',
				array(),
				CARE_INQUIRY_VERSION
			);
		}
	}

	/**
	 * Render dashboard page
	 */
	public function render_dashboard(): void {
		// Check capability
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'care-inquiry-management' ) );
		}

		// Get statistics
		$stats = $this->get_dashboard_stats();

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Clinic Dashboard', 'care-inquiry-management' ); ?></h1>
			<p class="subtitle"><?php esc_html_e( 'Appointment Inquiry Management System', 'care-inquiry-management' ); ?></p>

			<!-- Dashboard Cards Container -->
			<div class="care-dashboard-grid">

				<!-- Total Inquiries Card -->
				<div class="care-dashboard-card care-card-primary">
					<div class="care-card-content">
						<h2><?php echo absint( $stats['total'] ); ?></h2>
						<p><?php esc_html_e( 'Total Inquiries', 'care-inquiry-management' ); ?></p>
					</div>
					<div class="care-card-icon">📋</div>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . $this->post_type ) ); ?>" class="care-card-link">
						<?php esc_html_e( 'View All', 'care-inquiry-management' ); ?>
					</a>
				</div>

				<!-- New Inquiries Card -->
				<div class="care-dashboard-card care-card-new">
					<div class="care-card-content">
						<h2><?php echo absint( $stats['new'] ); ?></h2>
						<p><?php esc_html_e( 'New', 'care-inquiry-management' ); ?></p>
					</div>
					<div class="care-card-icon">🔴</div>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . $this->post_type . '&status=new' ) ); ?>" class="care-card-link">
						<?php esc_html_e( 'View New', 'care-inquiry-management' ); ?>
					</a>
				</div>

				<!-- Today's Appointments Card -->
				<div class="care-dashboard-card care-card-today">
					<div class="care-card-content">
						<h2><?php echo absint( $stats['today'] ); ?></h2>
						<p><?php esc_html_e( "Today's Appointments", 'care-inquiry-management' ); ?></p>
					</div>
					<div class="care-card-icon">📅</div>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . $this->post_type . '&appointment_date=' . gmdate( 'Y-m-d' ) ) ); ?>" class="care-card-link">
						<?php esc_html_e( 'View Today', 'care-inquiry-management' ); ?>
					</a>
				</div>

			</div>

			<!-- Info Section -->
			<div class="care-dashboard-info">
				<div class="care-info-box">
					<h3><?php esc_html_e( 'Quick Stats', 'care-inquiry-management' ); ?></h3>
					<ul>
						<li>
							<strong><?php esc_html_e( 'Response Rate:', 'care-inquiry-management' ); ?></strong>
							<?php
							$response_rate = $this->calculate_response_rate( $stats );
							echo esc_html( $response_rate . '%' );
							?>
						</li>
						<li>
							<strong><?php esc_html_e( 'Completion Rate:', 'care-inquiry-management' ); ?></strong>
							<?php
							$completion_rate = $this->calculate_completion_rate( $stats );
							echo esc_html( $completion_rate . '%' );
							?>
						</li>
						<li>
							<strong><?php esc_html_e( 'Last Updated:', 'care-inquiry-management' ); ?></strong>
							<?php echo esc_html( wp_date( 'M d, Y H:i', current_time( 'timestamp' ) ) ); ?>
						</li>
					</ul>
				</div>

				<div class="care-info-box">
					<h3><?php esc_html_e( 'Actions', 'care-inquiry-management' ); ?></h3>
					<p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . $this->post_type ) ); ?>" class="button button-primary">
							<?php esc_html_e( '📋 View All Inquiries', 'care-inquiry-management' ); ?>
						</a>
					</p>
					<p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=care-inquiry-settings' ) ); ?>" class="button">
							<?php esc_html_e( '⚙️ Settings', 'care-inquiry-management' ); ?>
						</a>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get dashboard statistics
	 *
	 * @return array Statistics array
	 */
	private function get_dashboard_stats(): array {
		global $wpdb;

		$post_type = $this->post_type;
		$today     = gmdate( 'Y-m-d' );

		// Get total inquiries
		$total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s",
				$post_type,
				'publish'
			)
		);

		// Get inquiries by status
		$statuses = array( 'new', 'contacted', 'completed', 'cancelled' );
		$stats    = array( 'total' => $total );

		foreach ( $statuses as $status ) {
			$stats[ $status ] = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->posts} p
					LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = %s
					WHERE p.post_type = %s AND p.post_status = %s AND pm.meta_value = %s",
					'_care_inquiry_status',
					$post_type,
					'publish',
					$status
				)
			);
		}

		// Get today's appointments
		$stats['today'] = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = %s AND pm.meta_value = %s",
				'_care_appointment_date',
				$post_type,
				'publish',
				$today
			)
		);

		return $stats;
	}

	/**
	 * Calculate response rate
	 *
	 * @param array $stats Statistics array
	 * @return int Response rate percentage
	 */
	private function calculate_response_rate( array $stats ): int {
		$total = $stats['total'];

		if ( $total === 0 ) {
			return 0;
		}

		$responded = $stats['contacted'] + $stats['completed'] + $stats['cancelled'];
		return (int) round( ( $responded / $total ) * 100 );
	}

	/**
	 * Calculate completion rate
	 *
	 * @param array $stats Statistics array
	 * @return int Completion rate percentage
	 */
	private function calculate_completion_rate( array $stats ): int {
		$total = $stats['total'];

		if ( $total === 0 ) {
			return 0;
		}

		$completed = $stats['completed'];
		return (int) round( ( $completed / $total ) * 100 );
	}
}
