<?php
/**
 * Care Inquiry Notifications
 *
 * Handles email notifications for inquiries
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Notifications
 *
 * Sends email notifications for new inquiries
 */
class Care_Inquiry_Notifications {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'care_inquiry_saved', array( $this, 'send_admin_notification' ), 10, 2 );
		add_action( 'care_inquiry_saved', array( $this, 'send_customer_confirmation' ), 10, 2 );
	}

	/**
	 * Send admin notification email
	 *
	 * @param int   $post_id Post ID
	 * @param array $data    Inquiry data
	 */
	public function send_admin_notification( $post_id, $data ): void {
		$admin_email = get_option( 'admin_email' );
		$site_name   = get_bloginfo( 'name' );
		$site_url    = home_url();

		$patient_name     = sanitize_text_field( $data['patient_name'] );
		$phone            = sanitize_text_field( $data['phone'] );
		$email            = sanitize_email( $data['email'] ?? '' );
		$appointment_date = sanitize_text_field( $data['date'] ?? '' );
		$appointment_time = sanitize_text_field( $data['time'] ?? '' );
		$reason           = sanitize_textarea_field( $data['message'] ?? '' );
		$country_code     = sanitize_text_field( $data['country_code'] ?? '+91' );

		$subject = sprintf(
			__( 'New Appointment Inquiry - %s', 'care-inquiry-management' ),
			$patient_name
		);

		$edit_link = admin_url( 'post.php?post=' . $post_id . '&action=edit' );

		$message = sprintf(
			__( 'Hello,

A new appointment inquiry has been received on %s.

Patient Details:
—————————————————
Name: %s
Phone: %s %s
Email: %s

Appointment Details:
—————————————————
Date: %s
Time: %s
Reason: %s

View and manage this inquiry:
%s

Best regards,
%s', 'care-inquiry-management' ),
			$site_name,
			$patient_name,
			$country_code,
			$phone,
			$email ?: 'N/A',
			$appointment_date ?: 'Not specified',
			$appointment_time ?: 'Not specified',
			$reason ?: 'Not specified',
			$edit_link,
			$site_name
		);

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . $site_name . ' <' . $admin_email . '>',
		);

		wp_mail( $admin_email, $subject, $message, $headers );
	}

	/**
	 * Send customer confirmation email
	 *
	 * @param int   $post_id Post ID
	 * @param array $data    Inquiry data
	 */
	public function send_customer_confirmation( $post_id, $data ): void {
		$customer_email = sanitize_email( $data['email'] ?? '' );

		// Only send if email is provided
		if ( empty( $customer_email ) ) {
			return;
		}

		$site_name    = get_bloginfo( 'name' );
		$patient_name = sanitize_text_field( $data['patient_name'] );

		$subject = sprintf(
			__( 'Appointment Request Received - %s', 'care-inquiry-management' ),
			$site_name
		);

		$message = sprintf(
			__( 'Dear %s,

Thank you for submitting your appointment inquiry to %s.

We have received your request and will review your details shortly. Our team will contact you within 24 hours to confirm your appointment.

Your Information:
—————————————————
Patient Name: %s
Phone: +91 %s

If you have any questions or need to make changes, please reply to this email or call us directly.

Best regards,
%s Team', 'care-inquiry-management' ),
			$patient_name,
			$site_name,
			$patient_name,
			sanitize_text_field( $data['phone'] ),
			$site_name
		);

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . $site_name . ' <' . get_option( 'admin_email' ) . '>',
		);

		wp_mail( $customer_email, $subject, $message, $headers );
	}
}
