<?php
/**
 * Care Inquiry Handler
 *
 * Handles saving inquiry data to the database
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Handler
 *
 * Saves inquiry submissions to the database
 */
class Care_Inquiry_Handler {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'care_save_inquiry', array( $this, 'save_inquiry' ), 10, 1 );
	}

	/**
	 * Save inquiry to database
	 *
	 * @param array $data Inquiry data
	 */
	public function save_inquiry( $data ): void {
		// Validate required fields
		if ( empty( $data['patient_name'] ) || empty( $data['phone'] ) ) {
			return;
		}

		// Extract and sanitize data
		$patient_name       = sanitize_text_field( $data['patient_name'] );
		$phone              = sanitize_text_field( $data['phone'] );
		$email              = sanitize_email( $data['email'] ?? '' );
		$appointment_date   = sanitize_text_field( $data['date'] ?? '' );
		$appointment_time   = sanitize_text_field( $data['time'] ?? '' );
		$reason             = sanitize_textarea_field( $data['message'] ?? '' );
		$country_code       = sanitize_text_field( $data['country_code'] ?? '+91' );

		// Create post object
		$post_data = array(
			'post_type'      => $this->post_type,
			'post_title'     => $patient_name,
			'post_status'    => 'publish',
			'post_content'   => $reason,
			'post_date'      => current_time( 'mysql' ),
			'post_date_gmt'  => gmdate( 'Y-m-d H:i:s' ),
		);

		// Insert the post
		$post_id = wp_insert_post( $post_data );

		if ( ! $post_id || is_wp_error( $post_id ) ) {
			return;
		}

		// Save meta data
		update_post_meta( $post_id, '_care_patient_name', $patient_name );
		update_post_meta( $post_id, '_care_phone', $phone );
		update_post_meta( $post_id, '_care_email', $email );
		update_post_meta( $post_id, '_care_appointment_date', $appointment_date );
		update_post_meta( $post_id, '_care_appointment_time', $appointment_time );
		update_post_meta( $post_id, '_care_reason', $reason );
		update_post_meta( $post_id, '_care_country_code', $country_code );
		update_post_meta( $post_id, '_care_inquiry_status', 'new' );
		update_post_meta( $post_id, '_care_inquiry_submitted_at', current_time( 'mysql' ) );

		// Trigger email notification
		do_action( 'care_inquiry_saved', $post_id, $data );
	}
}
