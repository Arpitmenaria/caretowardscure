<?php
/**
 * Care Inquiry Admin
 *
 * Handles admin-specific functionality
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Admin
 *
 * Adds admin functionality for inquiries
 */
class Care_Inquiry_Admin {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_filter( 'post_row_actions', array( $this, 'remove_row_actions' ), 10, 2 );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
	}

	/**
	 * Enqueue admin styles
	 */
	public function enqueue_admin_styles(): void {
		global $post_type;

		if ( $post_type === $this->post_type ) {
			wp_enqueue_style(
				'care-inquiry-admin',
				CARE_INQUIRY_URI . 'assets/admin-style.css',
				array(),
				CARE_INQUIRY_VERSION
			);
		}
	}

	/**
	 * Remove unwanted row actions
	 *
	 * @param array   $actions Array of actions
	 * @param WP_Post $post    Post object
	 * @return array Modified actions array
	 */
	public function remove_row_actions( $actions, $post ): array {
		if ( $post->post_type === $this->post_type ) {
			// Keep only Edit and Delete actions
			return array_intersect_key(
				$actions,
				array_flip( array( 'edit', 'delete' ) )
			);
		}

		return $actions;
	}

	/**
	 * Add admin menu items
	 */
	public function add_admin_menu(): void {
		// Add submenu for inquiry settings (optional)
		add_submenu_page(
			'edit.php?post_type=' . $this->post_type,
			__( 'Inquiry Settings', 'care-inquiry-management' ),
			__( 'Settings', 'care-inquiry-management' ),
			'manage_options',
			'care-inquiry-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Render settings page
	 */
	public function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'care-inquiry-management' ) );
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Inquiry Management Settings', 'care-inquiry-management' ); ?></h1>

			<div class="card">
				<h2><?php esc_html_e( 'Plugin Information', 'care-inquiry-management' ); ?></h2>
				<p>
					<strong><?php esc_html_e( 'Version:', 'care-inquiry-management' ); ?></strong>
					<?php echo esc_html( CARE_INQUIRY_VERSION ); ?>
				</p>
				<p>
					<strong><?php esc_html_e( 'Post Type:', 'care-inquiry-management' ); ?></strong>
					<code>care_inquiry</code>
				</p>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Features', 'care-inquiry-management' ); ?></h2>
				<ul style="list-style-type: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'Stores appointment inquiries from the booking form', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Tracks patient information (name, phone, email)', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Records appointment date and time', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Tracks reason for visit', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Manages inquiry status (New, Contacted, Confirmed, Completed, Cancelled)', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Sends email notifications to admin and customers', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Searchable and sortable inquiry list', 'care-inquiry-management' ); ?></li>
				</ul>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'How to Use', 'care-inquiry-management' ); ?></h2>
				<ol style="list-style-type: decimal; margin-left: 20px;">
					<li><?php esc_html_e( 'Go to Inquiries in the admin menu to view all bookings', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Click on an inquiry to view and edit details', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Update the inquiry status (New → Contacted → Confirmed → Completed)', 'care-inquiry-management' ); ?></li>
					<li><?php esc_html_e( 'Delete old inquiries once they are resolved', 'care-inquiry-management' ); ?></li>
				</ol>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Support', 'care-inquiry-management' ); ?></h2>
				<p>
					<?php esc_html_e( 'For issues or feature requests, please contact the theme author.', 'care-inquiry-management' ); ?>
				</p>
			</div>
		</div>
		<?php
	}
}
