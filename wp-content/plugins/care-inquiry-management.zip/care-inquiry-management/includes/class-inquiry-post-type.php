<?php
/**
 * Care Inquiry Post Type
 *
 * Registers and manages the custom post type for inquiries
 *
 * @package Care_Inquiry_Management
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Care_Inquiry_Post_Type
 *
 * Handles registration of custom post type for inquiries
 */
class Care_Inquiry_Post_Type {

	/**
	 * Post type slug
	 *
	 * @var string
	 */
	private string $post_type = 'care_inquiry';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_' . $this->post_type, array( $this, 'save_meta_boxes' ) );
		add_filter( 'manage_' . $this->post_type . '_posts_columns', array( $this, 'set_custom_columns' ) );
		add_action( 'manage_' . $this->post_type . '_posts_custom_column', array( $this, 'render_custom_columns' ), 10, 2 );
		add_filter( 'manage_edit-' . $this->post_type . '_sortable_columns', array( $this, 'set_sortable_columns' ) );
		add_filter( 'bulk_actions-edit-' . $this->post_type, array( $this, 'filter_bulk_actions' ) );
		add_action( 'admin_head-edit.php', array( $this, 'hide_wordpress_filters' ) );
		add_action( 'admin_menu', array( $this, 'hide_add_new_inquiry' ), 999 );
	}

	/**
	 * Register custom post type
	 */
	public function register(): void {
		$args = array(
			'label'               => __( 'Inquiries', 'care-inquiry-management' ),
			'labels'              => array(
				'name'               => __( 'Inquiries', 'care-inquiry-management' ),
				'singular_name'      => __( 'Inquiry', 'care-inquiry-management' ),
				'add_new'            => __( 'Add New Inquiry', 'care-inquiry-management' ),
				'add_new_item'       => __( 'Add New Inquiry', 'care-inquiry-management' ),
				'edit_item'          => __( 'Edit Inquiry', 'care-inquiry-management' ),
				'new_item'           => __( 'New Inquiry', 'care-inquiry-management' ),
				'view_item'          => __( 'View Inquiry', 'care-inquiry-management' ),
				'view_items'         => __( 'View Inquiries', 'care-inquiry-management' ),
				'search_items'       => __( 'Search Inquiries', 'care-inquiry-management' ),
				'not_found'          => __( 'No inquiries found', 'care-inquiry-management' ),
				'not_found_in_trash' => __( 'No inquiries found in trash', 'care-inquiry-management' ),
				'all_items'          => __( 'All Inquiries', 'care-inquiry-management' ),
				'archives'           => __( 'Inquiry Archives', 'care-inquiry-management' ),
				'attributes'         => __( 'Inquiry Attributes', 'care-inquiry-management' ),
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 25,
			'menu_icon'           => 'dashicons-email-alt',
			'show_in_admin_bar'   => true,
			'show_in_rest'        => true,
			'supports'            => array( 'title', 'editor' ),
			'taxonomies'          => array(),
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => false,
			'can_export'          => true,
			'delete_with_user'    => false,
			'publicly_queryable'  => false,
		);

		register_post_type( $this->post_type, $args );
	}

	/**
	 * Hide the "Add New Inquiry" submenu item
	 */
	public function hide_add_new_inquiry(): void {
		remove_submenu_page( 'edit.php?post_type=' . $this->post_type, 'post-new.php?post_type=' . $this->post_type );
	}

	/**
	 * Add meta boxes to inquiry editor
	 */
	public function add_meta_boxes(): void {
		add_meta_box(
			'inquiry_details',
			__( 'Inquiry Details', 'care-inquiry-management' ),
			array( $this, 'render_inquiry_details_meta_box' ),
			$this->post_type,
			'normal',
			'high'
		);

		add_meta_box(
			'inquiry_status',
			__( 'Inquiry Status', 'care-inquiry-management' ),
			array( $this, 'render_inquiry_status_meta_box' ),
			$this->post_type,
			'side',
			'high'
		);
	}

	/**
	 * Render inquiry details meta box
	 *
	 * @param WP_Post $post Post object
	 */
	public function render_inquiry_details_meta_box( $post ): void {
		wp_nonce_field( 'care_inquiry_nonce', 'care_inquiry_nonce_field' );

		$patient_name       = get_post_meta( $post->ID, '_care_patient_name', true );
		$phone              = get_post_meta( $post->ID, '_care_phone', true );
		$email              = get_post_meta( $post->ID, '_care_email', true );
		$appointment_date   = get_post_meta( $post->ID, '_care_appointment_date', true );
		$appointment_time   = get_post_meta( $post->ID, '_care_appointment_time', true );
		$reason             = get_post_meta( $post->ID, '_care_reason', true );
		$country_code       = get_post_meta( $post->ID, '_care_country_code', true );
		$submitted_at       = get_post_meta( $post->ID, '_care_inquiry_submitted_at', true );

		?>
		<div class="care-inquiry-details">
			<!-- Patient Information Section -->
			<div class="care-detail-section">
				<h3 class="care-section-title">👤 <?php esc_html_e( 'Patient Information', 'care-inquiry-management' ); ?></h3>

				<div class="care-form-group">
					<label for="care_patient_name"><?php esc_html_e( 'Patient Name', 'care-inquiry-management' ); ?></label>
					<input type="text" id="care_patient_name" name="care_patient_name" value="<?php echo esc_attr( $patient_name ); ?>" class="care-form-input" />
				</div>

				<div class="care-form-row">
					<div class="care-form-group care-form-group-half">
						<label for="care_country_code"><?php esc_html_e( 'Country Code', 'care-inquiry-management' ); ?></label>
						<input type="text" id="care_country_code" name="care_country_code" value="<?php echo esc_attr( $country_code ); ?>" class="care-form-input" placeholder="+91" />
					</div>
					<div class="care-form-group care-form-group-half">
						<label for="care_phone"><?php esc_html_e( 'Phone Number', 'care-inquiry-management' ); ?></label>
						<input type="tel" id="care_phone" name="care_phone" value="<?php echo esc_attr( $phone ); ?>" class="care-form-input" />
					</div>
				</div>

				<div class="care-form-group">
					<label for="care_email"><?php esc_html_e( 'Email Address', 'care-inquiry-management' ); ?></label>
					<input type="email" id="care_email" name="care_email" value="<?php echo esc_attr( $email ); ?>" class="care-form-input" />
				</div>
			</div>

			<!-- Appointment Information Section -->
			<div class="care-detail-section">
				<h3 class="care-section-title">📅 <?php esc_html_e( 'Appointment Information', 'care-inquiry-management' ); ?></h3>

				<div class="care-form-row">
					<div class="care-form-group care-form-group-half">
						<label for="care_appointment_date"><?php esc_html_e( 'Appointment Date', 'care-inquiry-management' ); ?></label>
						<input type="date" id="care_appointment_date" name="care_appointment_date" value="<?php echo esc_attr( $appointment_date ); ?>" class="care-form-input" />
					</div>
					<div class="care-form-group care-form-group-half">
						<label for="care_appointment_time"><?php esc_html_e( 'Appointment Time', 'care-inquiry-management' ); ?></label>
						<input type="time" id="care_appointment_time" name="care_appointment_time" value="<?php echo esc_attr( $appointment_time ); ?>" class="care-form-input" />
					</div>
				</div>
			</div>

			<!-- Visit Details Section -->
			<div class="care-detail-section">
				<h3 class="care-section-title">🏥 <?php esc_html_e( 'Visit Details', 'care-inquiry-management' ); ?></h3>

				<div class="care-form-group">
					<label for="care_reason"><?php esc_html_e( 'Reason for Visit / Message', 'care-inquiry-management' ); ?></label>
					<textarea id="care_reason" name="care_reason" class="care-form-textarea"><?php echo esc_textarea( $reason ); ?></textarea>
				</div>
			</div>

			<!-- Submission Information -->
			<div class="care-detail-section care-submission-info">
				<h3 class="care-section-title">📝 <?php esc_html_e( 'Submission Details', 'care-inquiry-management' ); ?></h3>
				<?php if ( $submitted_at ) : ?>
					<p><strong><?php esc_html_e( 'Submitted:', 'care-inquiry-management' ); ?></strong> <?php echo esc_html( wp_date( 'M d, Y H:i', strtotime( $submitted_at ) ) ); ?></p>
				<?php endif; ?>
				<p><strong><?php esc_html_e( 'Inquiry ID:', 'care-inquiry-management' ); ?></strong> #<?php echo esc_html( $post->ID ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render inquiry status meta box
	 *
	 * @param WP_Post $post Post object
	 */
	public function render_inquiry_status_meta_box( $post ): void {
		$status = get_post_meta( $post->ID, '_care_inquiry_status', true ) ?: 'new';
		$statuses = array(
			'new'        => array(
				'label'       => __( 'New', 'care-inquiry-management' ),
				'description' => __( 'Inquiry just received, awaiting review', 'care-inquiry-management' ),
				'icon'        => '🔴',
				'color'       => '#dc3545',
			),
			'contacted'  => array(
				'label'       => __( 'Contacted', 'care-inquiry-management' ),
				'description' => __( 'Patient has been contacted', 'care-inquiry-management' ),
				'icon'        => '📞',
				'color'       => '#ff9900',
			),
			'confirmed'  => array(
				'label'       => __( 'Confirmed', 'care-inquiry-management' ),
				'description' => __( 'Appointment confirmed', 'care-inquiry-management' ),
				'icon'        => '✅',
				'color'       => '#00a32a',
			),
			'completed'  => array(
				'label'       => __( 'Completed', 'care-inquiry-management' ),
				'description' => __( 'Appointment completed', 'care-inquiry-management' ),
				'icon'        => '✔️',
				'color'       => '#89909b',
			),
			'cancelled'  => array(
				'label'       => __( 'Cancelled', 'care-inquiry-management' ),
				'description' => __( 'Appointment was cancelled', 'care-inquiry-management' ),
				'icon'        => '❌',
				'color'       => '#dc3545',
			),
		);

		wp_nonce_field( 'care_inquiry_status_nonce', 'care_inquiry_status_nonce_field' );

		?>
		<div class="care-status-selector">
			<div class="care-status-current">
				<p class="care-status-label"><?php esc_html_e( 'Current Status:', 'care-inquiry-management' ); ?></p>
				<div class="care-status-badge care-status-<?php echo esc_attr( $status ); ?>">
					<?php echo esc_html( $statuses[ $status ]['icon'] . ' ' . $statuses[ $status ]['label'] ); ?>
				</div>
			</div>

			<div class="care-status-dropdown">
				<label for="care_inquiry_status"><?php esc_html_e( 'Change Status:', 'care-inquiry-management' ); ?></label>
				<select id="care_inquiry_status" name="care_inquiry_status" class="care-status-select">
					<?php foreach ( $statuses as $key => $status_info ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $status, $key ); ?>>
							<?php echo esc_html( $status_info['icon'] . ' ' . $status_info['label'] . ' - ' . $status_info['description'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<p class="care-status-note">
				<?php esc_html_e( 'Changes are saved automatically when you click the Update button.', 'care-inquiry-management' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Save meta boxes
	 *
	 * @param int $post_id Post ID
	 */
	public function save_meta_boxes( $post_id ): void {
		// Check nonces
		if ( ! isset( $_POST['care_inquiry_nonce_field'] ) || ! wp_verify_nonce( $_POST['care_inquiry_nonce_field'], 'care_inquiry_nonce' ) ) {
			return;
		}

		if ( ! isset( $_POST['care_inquiry_status_nonce_field'] ) || ! wp_verify_nonce( $_POST['care_inquiry_status_nonce_field'], 'care_inquiry_status_nonce' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Save inquiry details
		update_post_meta( $post_id, '_care_patient_name', sanitize_text_field( $_POST['care_patient_name'] ?? '' ) );
		update_post_meta( $post_id, '_care_phone', sanitize_text_field( $_POST['care_phone'] ?? '' ) );
		update_post_meta( $post_id, '_care_email', sanitize_email( $_POST['care_email'] ?? '' ) );
		update_post_meta( $post_id, '_care_appointment_date', sanitize_text_field( $_POST['care_appointment_date'] ?? '' ) );
		update_post_meta( $post_id, '_care_appointment_time', sanitize_text_field( $_POST['care_appointment_time'] ?? '' ) );
		update_post_meta( $post_id, '_care_reason', sanitize_textarea_field( $_POST['care_reason'] ?? '' ) );
		update_post_meta( $post_id, '_care_country_code', sanitize_text_field( $_POST['care_country_code'] ?? '' ) );
		update_post_meta( $post_id, '_care_inquiry_status', sanitize_text_field( $_POST['care_inquiry_status'] ?? 'new' ) );
	}

	/**
	 * Set custom admin columns
	 *
	 * @param array $columns Columns array
	 * @return array Modified columns array
	 */
	public function set_custom_columns( $columns ): array {
		$new_columns = array();
		$new_columns['cb']       = $columns['cb'];
		$new_columns['title']    = __( 'Patient Name', 'care-inquiry-management' );
		$new_columns['phone']    = __( 'Phone', 'care-inquiry-management' );
		$new_columns['email']    = __( 'Email', 'care-inquiry-management' );
		$new_columns['date']     = __( 'Appointment Date', 'care-inquiry-management' );
		$new_columns['status']   = __( 'Status', 'care-inquiry-management' );
		$new_columns['date_col'] = __( 'Submitted', 'care-inquiry-management' );

		return $new_columns;
	}

	/**
	 * Render custom admin columns
	 *
	 * @param string $column Column name
	 * @param int    $post_id Post ID
	 */
	public function render_custom_columns( $column, $post_id ): void {
		switch ( $column ) {
			case 'phone':
				$phone = get_post_meta( $post_id, '_care_phone', true );
				$country_code = get_post_meta( $post_id, '_care_country_code', true );
				echo esc_html( $country_code . ' ' . $phone );
				break;

			case 'email':
				$email = get_post_meta( $post_id, '_care_email', true );
				echo esc_html( $email );
				break;

			case 'date':
				$date = get_post_meta( $post_id, '_care_appointment_date', true );
				if ( $date ) {
					echo esc_html( wp_date( 'M d, Y', strtotime( $date ) ) );
				} else {
					echo '—';
				}
				break;

			case 'status':
				$status = get_post_meta( $post_id, '_care_inquiry_status', true ) ?: 'new';
				$status_labels = array(
					'new'        => '<span style="background-color: #0073aa; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">' . __( 'New', 'care-inquiry-management' ) . '</span>',
					'contacted'  => '<span style="background-color: #ff9900; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">' . __( 'Contacted', 'care-inquiry-management' ) . '</span>',
					'confirmed'  => '<span style="background-color: #00a32a; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">' . __( 'Confirmed', 'care-inquiry-management' ) . '</span>',
					'completed'  => '<span style="background-color: #89909b; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">' . __( 'Completed', 'care-inquiry-management' ) . '</span>',
					'cancelled'  => '<span style="background-color: #dc3545; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">' . __( 'Cancelled', 'care-inquiry-management' ) . '</span>',
				);
				echo wp_kses_post( $status_labels[ $status ] ?? '' );
				break;
		}
	}

	/**
	 * Set sortable columns
	 *
	 * @param array $columns Columns array
	 * @return array Modified columns array
	 */
	public function set_sortable_columns( $columns ): array {
		$columns['phone'] = '_care_phone';
		$columns['email'] = '_care_email';
		$columns['date']  = '_care_appointment_date';
		$columns['status'] = '_care_inquiry_status';

		return $columns;
	}

	/**
	 * Hide Add New button from inquiry list
	 *
	 * @param array   $actions Array of actions
	 * @param WP_Post $post    Post object
	 * @return array Modified actions
	 */
	public function remove_add_new_button( $actions, $post ): array {
		// Keep existing actions
		return $actions;
	}

	/**
	 * Remove bulk edit action
	 *
	 * @param array $actions Bulk actions
	 * @return array Modified bulk actions
	 */
	public function filter_bulk_actions( $actions ) {
		if ( isset( $actions['edit'] ) ) {
			unset( $actions['edit'] );
		}
		return $actions;
	}

	/**
	 * Hide WordPress default filters
	 */
	public function hide_wordpress_filters(): void {
		global $current_screen;

		if ( $current_screen && $current_screen->post_type === $this->post_type ) {
			echo '<style>
				/* Hide WordPress default date filter only */
				.tablenav .alignleft select[name="m"] {
					display: none !important;
				}
				/* Hide Apply button from date filter section */
				.tablenav .alignleft .button {
					display: none !important;
				}
				/* Fix duplicate bulk actions */
				.tablenav.bottom .alignleft {
					display: none !important;
				}
				/* Align top filters properly */
				.tablenav.top {
					margin-bottom: 15px;
				}
				.tablenav.top .alignleft {
					display: flex !important;
					align-items: center;
					gap: 8px;
					flex-wrap: nowrap;
				}
				/* Show custom filters */
				.care-filter-bar {
					display: inline-flex !important;
				}
				.care-filter-bar .care-filter-select {
					display: inline-block !important;
				}
			</style>';
		}
	}
}
