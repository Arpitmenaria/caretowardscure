/**
 * Care Inquiry Admin Notice
 * Handles dismissing new inquiry notices
 */

jQuery(document).ready(function($) {
	'use strict';

	/**
	 * Handle notice dismiss button click
	 */
	$('.care-notice-dismiss').on('click', function(e) {
		e.preventDefault();

		var $button = $(this);
		var $notice = $button.closest('.care-admin-notice');
		var nonce = $button.data('nonce');
		var userId = $button.data('user-id');

		// Send AJAX request
		$.ajax({
			url: careNoticeData.ajaxUrl,
			type: 'POST',
			data: {
				action: careNoticeData.action,
				nonce: nonce,
				user_id: userId
			},
			success: function(response) {
				if (response.success) {
					// Fade out and remove notice
					$notice.fadeOut(300, function() {
						$(this).remove();
					});
				}
			},
			error: function(error) {
				console.error('Error dismissing notice:', error);
			}
		});
	});
});
