<?php
/**
 * Care Inquiry Management
 *
 * @package Care_Inquiry_Management
 * @version 1.0.0
 * @author Your Name
 *
 * Plugin Name: Care Inquiry Management
 * Plugin URI: https://careatourscure.com
 * Description: Manages appointment and inquiry submissions for Care Towards Cure theme
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * Author: Care Towards Cure
 * Author URI: https://careatourscure.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: care-inquiry-management
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

// Plugin constants
define( 'CARE_INQUIRY_VERSION', '1.0.0' );
define( 'CARE_INQUIRY_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARE_INQUIRY_URI', plugin_dir_url( __FILE__ ) );
define( 'CARE_INQUIRY_FILE', __FILE__ );

// Load plugin classes immediately
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-post-type.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-handler.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-notifications.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-admin.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-dashboard.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-filters.php';
require_once CARE_INQUIRY_DIR . 'includes/class-inquiry-admin-notice.php';

/**
 * Load plugin text domain for translations
 */
function care_inquiry_load_textdomain(): void {
	load_plugin_textdomain(
		'care-inquiry-management',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
}
add_action( 'plugins_loaded', 'care_inquiry_load_textdomain' );

/**
 * Initialize plugin classes
 */
function care_inquiry_init(): void {
	new Care_Inquiry_Post_Type();
	new Care_Inquiry_Handler();
	new Care_Inquiry_Notifications();
	new Care_Inquiry_Admin();
	new Care_Inquiry_Dashboard();
	new Care_Inquiry_Filters();
	new Care_Inquiry_Admin_Notice();
}
add_action( 'init', 'care_inquiry_init', 1 );

/**
 * Plugin activation hook
 */
function care_inquiry_activate(): void {
	// Flush rewrite rules after post type is registered
	// Post type will be registered via init hook
	flush_rewrite_rules( false );
}
register_activation_hook( __FILE__, 'care_inquiry_activate' );

/**
 * Plugin deactivation hook
 */
function care_inquiry_deactivate(): void {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'care_inquiry_deactivate' );
