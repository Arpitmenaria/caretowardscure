<?php
/**
 * The front page template
 *
 * Displays the clinic landing page with all sections
 *
 * @package Care_Towards_Cure_Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

	<main id="main-content">
		<?php
		// ===== MODERN HERO SECTION WITH CAROUSEL =====
		$hero_badge    = get_theme_mod( 'care_hero_badge', __( 'TRUSTED HEALTHCARE PROVIDER', 'care-towards-cure' ) );
		$hero_title    = get_theme_mod( 'care_hero_title', __( 'Your Health, Our Priority', 'care-towards-cure' ) );
		$hero_subtitle = get_theme_mod( 'care_hero_subtitle', __( 'Experience world-class medical expertise with a human touch. Our specialized team is dedicated to providing personalized care tailored to your unique journey.', 'care-towards-cure' ) );
		$btn1_text     = get_theme_mod( 'care_hero_btn1_text', __( 'Book Appointment', 'care-towards-cure' ) );
		$btn1_link     = get_theme_mod( 'care_hero_btn1_link', '#contact' );
		$btn2_text     = get_theme_mod( 'care_hero_btn2_text', __( 'Call Now', 'care-towards-cure' ) );
		$btn2_link     = get_theme_mod( 'care_hero_btn2_link', 'tel:+1555123456' );

		// Get hero images (carousel)
		$hero_images = array();
		for ( $i = 1; $i <= 4; $i++ ) {
			$image_id = get_theme_mod( 'care_hero_image_' . $i );
			if ( $image_id ) {
				$hero_images[] = wp_get_attachment_url( $image_id );
			}
		}
		?>
		<section class="hero-modern" role="region" aria-label="<?php esc_attr_e( 'Hero Section', 'care-towards-cure' ); ?>">
			<div class="container">
				<div class="hero-modern-wrapper">
					<!-- Left Content Area -->
					<div class="hero-content-left">
						<!-- Badge -->
						<div class="hero-badge">
							<?php echo esc_html( $hero_badge ); ?>
						</div>

						<!-- Main Title -->
						<h1><?php echo esc_html( $hero_title ); ?></h1>

						<!-- Subtitle -->
						<p class="hero-subtitle">
							<?php echo esc_html( $hero_subtitle ); ?>
						</p>

						<!-- CTA Buttons -->
						<div class="hero-cta-buttons">
							<button type="button" class="hero-btn hero-btn-primary" data-open-modal="appointmentModal">
								<?php echo esc_html( $btn1_text ); ?>
							</button>
							<a href="<?php echo esc_url( $btn2_link ); ?>" class="hero-btn hero-btn-secondary">
								<?php echo care_get_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php echo esc_html( $btn2_text ); ?>
							</a>
						</div>
					</div>

					<!-- Right Image Carousel -->
					<?php if ( ! empty( $hero_images ) ) : ?>
						<div class="hero-carousel-container">
							<div class="hero-carousel" role="region" aria-label="<?php esc_attr_e( 'Hero Image Carousel', 'care-towards-cure' ); ?>">
								<div class="hero-carousel-track">
									<?php
									foreach ( $hero_images as $index => $image_url ) {
										?>
										<div class="hero-carousel-slide">
											<img
												src="<?php echo esc_url( $image_url ); ?>"
												alt="<?php printf( esc_attr__( 'Care Towards Cure - Hero Image %d', 'care-towards-cure' ), $index + 1 ); ?>"
												loading="lazy"
											>
										</div>
										<?php
									}
									?>
								</div>

								<!-- Navigation Dots -->
								<div class="hero-carousel-controls" role="tablist">
									<?php
									foreach ( $hero_images as $index => $image_url ) {
										?>
										<button
											class="hero-carousel-dot"
											role="tab"
											aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>"
											aria-label="<?php printf( esc_attr__( 'Go to slide %d', 'care-towards-cure' ), $index + 1 ); ?>"
										></button>
										<?php
									}
									?>
								</div>

								<!-- Navigation Arrows -->
								<?php if ( count( $hero_images ) > 1 ) : ?>
									<button class="hero-carousel-arrow prev" aria-label="<?php esc_attr_e( 'Previous slide', 'care-towards-cure' ); ?>">
										<?php echo care_get_icon( 'arrow-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</button>
									<button class="hero-carousel-arrow next" aria-label="<?php esc_attr_e( 'Next slide', 'care-towards-cure' ); ?>">
										<?php echo care_get_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</button>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</section>

		<?php
		// ===== MISSION & LEGACY SECTION =====
		$mission_title    = get_theme_mod( 'care_mission_title', __( 'Our Mission & Legacy', 'care-towards-cure' ) );
		$mission_desc_1   = get_theme_mod( 'care_mission_desc_1', __( 'Founded in 1998, Vitae Clinic has been at the forefront of medical innovation for over two decades. Our journey began with a simple vision: to provide high-quality, patient-centric care that combines clinical expertise with a compassionate touch.', 'care-towards-cure' ) );
		$mission_desc_2   = get_theme_mod( 'care_mission_desc_2', __( 'Today, we are recognized as a leader in multi-specialty healthcare, serving thousands of patients annually with a commitment to integrity, transparency, and medical excellence.', 'care-towards-cure' ) );
		?>
		<section class="mission-section" id="mission">
			<div class="container">
				<div class="mission-wrapper">
					<!-- Left Content Area -->
					<div class="mission-content">
						<h2 class="mission-title"><?php echo esc_html( $mission_title ); ?></h2>
						<div class="mission-description">
							<?php echo wp_kses_post( wpautop( $mission_desc_1 ) ); ?>
							<?php echo wp_kses_post( wpautop( $mission_desc_2 ) ); ?>
						</div>
					</div>

					<!-- Right Stats Grid -->
					<div class="mission-stats-grid">
						<?php
						$stat_defaults = array(
							array( 'value' => '25+', 'label' => 'Years Excellence', 'color' => '' ),
							array( 'value' => '50+', 'label' => 'Happy Patients', 'color' => 'primary' ),
							array( 'value' => '40+', 'label' => 'Specialists', 'color' => '' ),
							array( 'value' => '12+', 'label' => 'Awards Won', 'color' => 'secondary' ),
						);

						for ( $i = 1; $i <= 4; $i++ ) {
							$default = $stat_defaults[ $i - 1 ];
							$stat_value = get_theme_mod( 'care_mission_stat_' . $i . '_value', $default['value'] );
							$stat_label = get_theme_mod( 'care_mission_stat_' . $i . '_label', $default['label'] );
							$stat_color = get_theme_mod( 'care_mission_stat_' . $i . '_color', $default['color'] );

							$card_class = 'mission-stat-card';
							if ( $stat_color === 'primary' ) {
								$card_class .= ' primary';
							} elseif ( $stat_color === 'secondary' ) {
								$card_class .= ' secondary';
							}
							?>
							<div class="<?php echo esc_attr( $card_class ); ?>">
								<?php
								$numeric_value = intval( $stat_value );
								$suffix = strpos( $stat_value, '+' ) !== false ? '+' : '';
								?>
								<span class="mission-stat-value" data-count="<?php echo esc_attr( $numeric_value ); ?>" data-suffix="<?php echo esc_attr( $suffix ); ?>"><?php echo esc_html( $stat_value ); ?></span>
								<span class="mission-stat-label"><?php echo esc_html( $stat_label ); ?></span>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>
		</section>

		<?php
		// ===== SERVICES SECTION =====
		$services_badge    = get_theme_mod( 'care_services_badge', __( 'OUR SERVICES', 'care-towards-cure' ) );
		$services_title    = get_theme_mod( 'care_services_title', __( 'Comprehensive Care Portfolio', 'care-towards-cure' ) );
		$services_desc     = get_theme_mod( 'care_services_description', __( 'Explore our wide range of medical services and specialties', 'care-towards-cure' ) );
		?>
		<section class="services-section" id="services">
			<div class="container">
				<!-- Services Header -->
				<div class="services-header">
					<div class="services-badge"><?php echo esc_html( $services_badge ); ?></div>
					<h2 class="services-title"><?php echo esc_html( $services_title ); ?></h2>
					<?php if ( $services_desc ) : ?>
						<p class="services-description"><?php echo esc_html( $services_desc ); ?></p>
					<?php endif; ?>
				</div>

				<!-- Services Scroll Wrapper -->
				<div class="services-scroll-wrapper">
					<!-- Scroll Navigation Buttons -->
					<div class="services-scroll-nav">
						<button
							class="services-scroll-btn prev"
							aria-label="<?php esc_attr_e( 'Scroll services left', 'care-towards-cure' ); ?>"
						>
							<?php echo care_get_icon( 'arrow-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</button>
						<button
							class="services-scroll-btn next"
							aria-label="<?php esc_attr_e( 'Scroll services right', 'care-towards-cure' ); ?>"
						>
							<?php echo care_get_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</button>
					</div>

					<!-- Services Grid -->
					<div class="services-grid" role="region" aria-label="<?php esc_attr_e( 'Services carousel', 'care-towards-cure' ); ?>">
						<?php
						$icons = array( '🩺', '👶', '🦴', '❤️', '🏃', '🦷' );

						$service_defaults = array(
							array( 'title' => __( 'General Consultation', 'care-towards-cure' ), 'desc' => __( 'Your first point of contact for all medical concerns and regular checkups.', 'care-towards-cure' ), 'link' => '#' ),
							array( 'title' => __( 'Pediatrics', 'care-towards-cure' ), 'desc' => __( 'Specialized care for our youngest patients.', 'care-towards-cure' ), 'link' => '#' ),
							array( 'title' => __( 'Orthopedics', 'care-towards-cure' ), 'desc' => __( 'Focusing on bone and joint health.', 'care-towards-cure' ), 'link' => '#' ),
							array( 'title' => __( 'Cardiology', 'care-towards-cure' ), 'desc' => __( 'Advanced cardiac monitoring.', 'care-towards-cure' ), 'link' => '#' ),
							array( 'title' => __( 'Physiotherapy', 'care-towards-cure' ), 'desc' => __( 'Rehabilitation programs tailored to recovery.', 'care-towards-cure' ), 'link' => '#' ),
							array( 'title' => __( 'Dental Care', 'care-towards-cure' ), 'desc' => __( 'Complete oral hygiene care.', 'care-towards-cure' ), 'link' => '#' ),
						);

						for ( $i = 1; $i <= 6; $i++ ) {
							$default = $service_defaults[ $i - 1 ];
							$service_title = get_theme_mod( 'care_service_' . $i . '_title', $default['title'] );
							$service_desc  = get_theme_mod( 'care_service_' . $i . '_description', $default['desc'] );
							$service_link  = get_theme_mod( 'care_service_' . $i . '_link', $default['link'] );

							if ( true ) {
								?>
								<div class="service-card">
									<h3 class="service-title"><?php echo esc_html( $service_title ); ?></h3>

									<p class="service-description"><?php echo esc_html( $service_desc ); ?></p>
								</div>
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</section>

		<?php
		// ===== GALLERY/FACILITIES SECTION =====
		$gallery_badge    = get_theme_mod( 'care_gallery_badge', __( 'WORLD-CLASS FACILITIES', 'care-towards-cure' ) );
		$gallery_title    = get_theme_mod( 'care_gallery_title', __( 'World-Class Facilities', 'care-towards-cure' ) );
		$gallery_desc     = get_theme_mod( 'care_gallery_description', __( 'Equipped with the latest diagnostic and therapeutic technology.', 'care-towards-cure' ) );
		?>
		<section class="gallery-section" id="gallery">
			<div class="container">
				<!-- Gallery Header -->
				<div class="gallery-header">
					<div class="gallery-header-content">
						<div class="gallery-badge"><?php echo esc_html( $gallery_badge ); ?></div>
						<h2 class="gallery-title"><?php echo esc_html( $gallery_title ); ?></h2>
						<?php if ( $gallery_desc ) : ?>
							<p class="gallery-description"><?php echo esc_html( $gallery_desc ); ?></p>
						<?php endif; ?>
					</div>
				</div>

				<!-- Gallery Scroll Controls -->
				<div class="gallery-scroll-wrapper">
					<button class="gallery-scroll-btn prev" aria-label="<?php esc_attr_e( 'Previous facility', 'care-towards-cure' ); ?>">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<polyline points="15 18 9 12 15 6"></polyline>
						</svg>
					</button>

					<!-- Gallery Horizontal Scroll Grid -->
					<div class="gallery-grid" role="region" aria-label="<?php esc_attr_e( 'Facilities gallery', 'care-towards-cure' ); ?>">
						<?php
						$facility_defaults = array(
							array( 'title' => __( 'Advanced Imaging Center', 'care-towards-cure' ), 'image' => '' ),
							array( 'title' => __( 'Consultation Room', 'care-towards-cure' ), 'image' => '' ),
							array( 'title' => __( 'Research Lab', 'care-towards-cure' ), 'image' => '' ),
							array( 'title' => __( 'Patient Comfort Lounge', 'care-towards-cure' ), 'image' => '' ),
							array( 'title' => __( 'Surgery Suite', 'care-towards-cure' ), 'image' => '' ),
							array( 'title' => __( 'Emergency Care', 'care-towards-cure' ), 'image' => '' ),
						);

						for ( $i = 1; $i <= 6; $i++ ) {
							$default        = $facility_defaults[ $i - 1 ];
							$facility_title = get_theme_mod( 'care_facility_' . $i . '_title', $default['title'] );
							$facility_image = get_theme_mod( 'care_facility_' . $i . '_image' );

							$image_url = $facility_image ? wp_get_attachment_url( $facility_image ) : 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"%3E%3Crect fill="%23e0e0e0" width="400" height="300"/%3E%3C/svg%3E';
							?>
							<div class="gallery-item">
								<?php if ( $image_url ) : ?>
									<img
										src="<?php echo esc_url( $image_url ); ?>"
										alt="<?php echo esc_attr( $facility_title ); ?>"
										class="gallery-item-image"
										loading="lazy"
									>
								<?php endif; ?>
								<div class="gallery-item-overlay"></div>
								<h3 class="gallery-item-title"><?php echo esc_html( $facility_title ); ?></h3>
							</div>
							<?php
						}
						?>
					</div>

					<button class="gallery-scroll-btn next" aria-label="<?php esc_attr_e( 'Next facility', 'care-towards-cure' ); ?>">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<polyline points="9 18 15 12 9 6"></polyline>
						</svg>
					</button>
				</div>
			</div>
		</section>

		<?php
		// ===== DOCTOR/TEAM MEMBER SECTION =====
		$doctor_badge     = get_theme_mod( 'care_doctor_badge', __( 'HEAD OF CLINICAL EXCELLENCE', 'care-towards-cure' ) );
		$doctor_name      = get_theme_mod( 'care_doctor_name', __( 'Dr. Jonathan Healthington', 'care-towards-cure' ) );
		$doctor_title     = get_theme_mod( 'care_doctor_title', __( 'Chief Cardiologist & Medical Director', 'care-towards-cure' ) );
		$doctor_image     = get_theme_mod( 'care_doctor_image' );
		$doctor_exp       = get_theme_mod( 'care_doctor_experience', __( '25+ Years', 'care-towards-cure' ) );
		$doctor_quals     = get_theme_mod( 'care_doctor_qualifications', __( 'MD, PhD, FACC', 'care-towards-cure' ) );
		$doctor_desc      = get_theme_mod( 'care_doctor_description', __( 'Dr. Healthington has pioneered several non-invasive cardiac procedures and leads our team with a philosophy centered on "Precision with Heart." Under his guidance, HealthPremium has achieved a 99.2% patient satisfaction rating.', 'care-towards-cure' ) );
		?>
		<section class="doctor-section" id="doctor">
			<div class="container">
				<div class="doctor-wrapper">
					<!-- Doctor Image -->
					<div class="doctor-image-container">
						<?php
						$image_url = $doctor_image ? wp_get_attachment_url( $doctor_image ) : 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"%3E%3Crect fill="%23e0e0e0" width="400" height="500"/%3E%3C/svg%3E';
						?>
						<img
							src="<?php echo esc_url( $image_url ); ?>"
							alt="<?php echo esc_attr( $doctor_name ); ?>"
							class="doctor-image"
							loading="lazy"
						>
					</div>

					<!-- Doctor Content -->
					<div class="doctor-content">
						<!-- Badge -->
						<span class="doctor-badge"><?php echo esc_html( $doctor_badge ); ?></span>

						<!-- Name -->
						<h2 class="doctor-name"><?php echo esc_html( $doctor_name ); ?></h2>

						<!-- Title -->
						<p class="doctor-title"><?php echo esc_html( $doctor_title ); ?></p>

						<!-- Info Boxes -->
						<div class="doctor-info-boxes">
							<div class="doctor-info-box">
								<span class="doctor-info-label"><?php esc_html_e( 'Experience', 'care-towards-cure' ); ?></span>
								<p class="doctor-info-value"><?php echo esc_html( $doctor_exp ); ?></p>
							</div>
							<div class="doctor-info-box">
								<span class="doctor-info-label"><?php esc_html_e( 'Qualifications', 'care-towards-cure' ); ?></span>
								<p class="doctor-info-value"><?php echo esc_html( $doctor_quals ); ?></p>
							</div>
						</div>

						<!-- Description -->
						<?php if ( $doctor_desc ) : ?>
							<p class="doctor-description"><?php echo esc_html( $doctor_desc ); ?></p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>

		<?php
		// ===== TIMINGS/OPERATING HOURS SECTION =====
		$timings_emergency_text = get_theme_mod( 'care_timings_emergency', __( '24/7 Emergency support is available via our helpline.', 'care-towards-cure' ) );
		$benefits_title         = get_theme_mod( 'care_benefits_title', __( 'Why Patients Choose Vitae', 'care-towards-cure' ) );
		?>
		<section class="timings-section" id="timings">
			<div class="container">
				<div class="timings-wrapper">
					<!-- Operating Hours Card -->
					<div class="hours-card">
						<div class="hours-header">
							<span class="hours-icon">🕐</span>
							<h2 class="hours-title"><?php esc_html_e( 'Clinic Operating Hours', 'care-towards-cure' ); ?></h2>
						</div>

						<ul class="hours-list">
							<?php
							$hours_defaults = array(
								array( 'day' => 'Monday - Friday', 'time' => '08:00 AM - 08:00 PM', 'type' => 'primary' ),
								array( 'day' => 'Saturday', 'time' => '09:00 AM - 05:00 PM', 'type' => 'secondary' ),
								array( 'day' => 'Sunday', 'time' => 'Closed / Emergency Only', 'type' => 'closed' ),
							);

							for ( $i = 0; $i < count( $hours_defaults ); $i++ ) {
								$default = $hours_defaults[ $i ];
								$day     = get_theme_mod( 'care_hours_' . ( $i + 1 ) . '_day', $default['day'] );
								$time    = get_theme_mod( 'care_hours_' . ( $i + 1 ) . '_time', $default['time'] );
								$type    = get_theme_mod( 'care_hours_' . ( $i + 1 ) . '_type', $default['type'] );
								?>
								<li class="hours-item">
									<span class="hours-day"><?php echo esc_html( $day ); ?></span>
									<span class="hours-time <?php echo esc_attr( $type ); ?>"><?php echo esc_html( $time ); ?></span>
								</li>
								<?php
							}
							?>
						</ul>

						<?php if ( $timings_emergency_text ) : ?>
							<div class="emergency-notice">
								<span class="emergency-icon">ℹ️</span>
								<p class="emergency-text"><?php echo esc_html( $timings_emergency_text ); ?></p>
							</div>
						<?php endif; ?>
					</div>

					<!-- Benefits/Why Choose Section -->
					<div class="benefits-wrapper">
						<h2 class="benefits-title"><?php echo esc_html( $benefits_title ); ?></h2>

						<div class="benefits-grid">
							<?php
							$benefit_defaults = array(
								array( 'title' => 'Patient-Centric Care', 'desc' => 'We prioritize your comfort and well-being with personalized treatment plans and attentive service.', 'icon' => '❤️', 'type' => 'primary' ),
								array( 'title' => 'Modern Technology', 'desc' => 'Utilizing the latest medical equipment and digital health records for accurate diagnosis.', 'icon' => '⚙️', 'type' => 'secondary' ),
								array( 'title' => 'Board-Certified Experts', 'desc' => 'Our specialists are world-class professionals with extensive experience in their fields.', 'icon' => '🏆', 'type' => 'dark' ),
							);

							for ( $i = 1; $i <= 3; $i++ ) {
								$default = $benefit_defaults[ $i - 1 ];
								$title   = get_theme_mod( 'care_benefit_' . $i . '_title', $default['title'] );
								$desc    = get_theme_mod( 'care_benefit_' . $i . '_description', $default['desc'] );
								$icon    = get_theme_mod( 'care_benefit_' . $i . '_icon', $default['icon'] );
								$type    = get_theme_mod( 'care_benefit_' . $i . '_type', $default['type'] );
								?>
								<div class="benefit-card">
									<div class="benefit-icon <?php echo esc_attr( $type ); ?>"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
									<div class="benefit-content">
										<h3 class="benefit-title"><?php echo esc_html( $title ); ?></h3>
										<p class="benefit-description"><?php echo esc_html( $desc ); ?></p>
									</div>
								</div>
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
		// ===== REVIEWS/TESTIMONIALS SECTION =====
		$reviews_badge = get_theme_mod( 'care_reviews_badge', __( 'PATIENT STORIES', 'care-towards-cure' ) );
		$reviews_title = get_theme_mod( 'care_reviews_title', __( 'What Our Patients Say', 'care-towards-cure' ) );
		?>
		<section class="reviews-section" id="reviews">
			<div class="container">
				<!-- Reviews Header -->
				<div class="reviews-header">
					<div class="reviews-badge"><?php echo esc_html( $reviews_badge ); ?></div>
					<h2 class="reviews-title"><?php echo esc_html( $reviews_title ); ?></h2>
				</div>

				<!-- Reviews Carousel -->
				<div class="reviews-carousel" role="region" aria-label="<?php esc_attr_e( 'Patient testimonials', 'care-towards-cure' ); ?>">
					<div class="reviews-track">
						<?php
						$review_defaults = array(
							array(
								'name'   => 'Sarah Jenkins',
								'role'   => 'General Checkup',
								'rating' => 5,
								'text'   => 'The level of professionalism and care I received at HealthPremium was unmatched. Dr. Jonathan took the time to explain everything clearly.',
								'featured' => false,
							),
							array(
								'name'   => 'Robert Wilson',
								'role'   => 'Emergency Care',
								'rating' => 5,
								'text'   => 'Emergency services were lightning fast. They saved my husband\'s life. I can\'t thank the staff enough for their dedication and calm under pressure.',
								'featured' => true,
							),
							array(
								'name'   => 'Michael Chen',
								'role'   => 'Diagnostics',
								'rating' => 5,
								'text'   => 'Finally a clinic that respects your time. Digital check-in was seamless, and the facilities are remarkably clean and modern.',
								'featured' => false,
							),
						);

						for ( $i = 1; $i <= 3; $i++ ) {
							$default   = $review_defaults[ $i - 1 ];
							$name      = get_theme_mod( 'care_review_' . $i . '_name', $default['name'] );
							$role      = get_theme_mod( 'care_review_' . $i . '_role', $default['role'] );
							$rating    = get_theme_mod( 'care_review_' . $i . '_rating', $default['rating'] );
							$text      = get_theme_mod( 'care_review_' . $i . '_text', $default['text'] );
							$featured  = get_theme_mod( 'care_review_' . $i . '_featured', $default['featured'] );
							$initial   = strtoupper( substr( $name, 0, 1 ) );

							$card_class = 'review-card';
							if ( $featured ) {
								$card_class .= ' featured';
							}
							?>
							<div class="<?php echo esc_attr( $card_class ); ?>">
								<!-- Stars -->
								<div class="review-stars">
									<?php
									for ( $s = 0; $s < $rating; $s++ ) {
										echo '<span class="review-star">★</span>';
									}
									?>
								</div>

								<!-- Review Text -->
								<p class="review-text"><?php echo esc_html( $text ); ?></p>

								<!-- Author Info -->
								<div class="review-author-section">
									<div class="review-avatar"><?php echo esc_html( $initial ); ?></div>
									<div class="review-author-info">
										<p class="review-author-name"><?php echo esc_html( $name ); ?></p>
										<p class="review-author-role"><?php echo esc_html( $role ); ?></p>
									</div>
								</div>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>
		</section>

		<?php
		// ===== CONTACT SECTION =====
		$contact_badge        = get_theme_mod( 'care_contact_badge', __( 'GET IN TOUCH', 'care-towards-cure' ) );
		$contact_title        = get_theme_mod( 'care_contact_title', __( 'Contact Our Clinic', 'care-towards-cure' ) );
		$contact_address      = get_theme_mod( 'care_contact_address', __( 'C-114, Triveni Nagar Rd, opp. Triveni Heights, Shopping Centre, Vishveshvariya Nagar, Arjun Nagar, Jaipur, Rajasthan 302019', 'care-towards-cure' ) );
		$contact_phone        = get_theme_mod( 'care_contact_phone', '+91 9414311475' );
		$contact_email        = get_theme_mod( 'care_contact_email', 'caretowardscure@gmail.com' );
		$contact_map_url      = get_theme_mod( 'care_contact_map_url', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0!2d75.8!3d26.9!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4c1234567890%3A0xabcdef1234567890!2sCare%20Towards%20Cure!5e0!3m2!1sen!2sus!4v1638000000000' );
		?>
		<section class="contact-section" id="contact">
			<div class="container">
				<div class="contact-wrapper">
					<!-- Contact Form Side -->
					<div class="contact-form-wrapper">
						<!-- Header -->
						<div class="contact-header">
							<div class="contact-badge"><?php echo esc_html( $contact_badge ); ?></div>
							<h2 class="contact-title"><?php echo esc_html( $contact_title ); ?></h2>
						</div>

						<!-- Contact Info Items -->
						<div class="contact-info-items">
							<!-- Address -->
							<div class="contact-info-item">
								<span class="contact-info-icon">📍</span>
								<div class="contact-info-content">
									<p class="contact-info-label"><?php esc_html_e( 'Clinic Address', 'care-towards-cure' ); ?></p>
									<p class="contact-info-value"><?php echo esc_html( $contact_address ); ?></p>
								</div>
							</div>

							<!-- Phone -->
							<div class="contact-info-item">
								<span class="contact-info-icon">📞</span>
								<div class="contact-info-content">
									<p class="contact-info-label"><?php esc_html_e( 'Call Us', 'care-towards-cure' ); ?></p>
									<p class="contact-info-value"><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $contact_phone ) ); ?>"><?php echo esc_html( $contact_phone ); ?></a></p>
								</div>
							</div>

							<!-- Email -->
							<div class="contact-info-item">
								<span class="contact-info-icon">✉️</span>
								<div class="contact-info-content">
									<p class="contact-info-label"><?php esc_html_e( 'Email Support', 'care-towards-cure' ); ?></p>
									<p class="contact-info-value"><a href="mailto:<?php echo esc_attr( $contact_email ); ?>"><?php echo esc_html( $contact_email ); ?></a></p>
								</div>
							</div>
						</div>
					</div>

					<!-- Google Map Side -->
					<div class="contact-map-wrapper">
						<?php if ( $contact_map_url ) : ?>
							<iframe
								src="<?php echo esc_url( $contact_map_url ); ?>"
								width="100%"
								height="100%"
								style="border:0;"
								allowfullscreen=""
								loading="lazy"
								referrerpolicy="no-referrer-when-downgrade"
							></iframe>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>

		<!-- Success Modal -->
		<div id="successModal" class="modal-overlay">
			<div class="modal-dialog">
				<div class="modal-body modal-success-body">
					<div class="success-icon">✓</div>
					<h2 class="success-title"><?php esc_html_e( 'Thank You!', 'care-towards-cure' ); ?></h2>
					<p class="success-message">
						<?php esc_html_e( 'Your appointment inquiry has been submitted successfully. Our clinic staff will contact you shortly.', 'care-towards-cure' ); ?>
					</p>
					<button type="button" class="modal-btn modal-btn-close-success" data-close-success="successModal">
						<?php esc_html_e( 'Close', 'care-towards-cure' ); ?>
					</button>
				</div>
			</div>
		</div>

		<!-- Appointment Modal -->
		<div id="appointmentModal" class="modal-overlay">
			<div class="modal-dialog">
				<!-- Modal Header -->
				<div class="modal-header">
					<h2 class="modal-title"><?php esc_html_e( 'Book an Appointment', 'care-towards-cure' ); ?></h2>
					<button type="button" class="modal-close" aria-label="<?php esc_attr_e( 'Close modal', 'care-towards-cure' ); ?>">✕</button>
				</div>

				<!-- Modal Body -->
				<div class="modal-body">
					<form id="appointmentForm" method="POST">
						<!-- Patient Name & Mobile Number -->
						<div class="form-row two-col">
							<div class="form-field">
								<label class="form-label" for="patient-name"><?php esc_html_e( 'Patient Name', 'care-towards-cure' ); ?></label>
								<input
									type="text"
									id="patient-name"
									name="patient_name"
									class="form-input"
									placeholder="John Doe"
									required
								>
							</div>
							<div class="form-field">
								<label class="form-label" for="phone"><?php esc_html_e( 'Mobile Number', 'care-towards-cure' ); ?></label>
								<input
									type="tel"
									id="phone"
									name="phone"
									class="form-input"
									placeholder="+91 (555) 000-0000"
									required
								>
							</div>
						</div>

						<!-- Email -->
						<div class="form-field">
							<label class="form-label" for="email"><?php esc_html_e( 'Email (Optional)', 'care-towards-cure' ); ?></label>
							<input
								type="email"
								id="email"
								name="email"
								class="form-input"
								placeholder="john.doe@example.com"
							>
						</div>

						<!-- Date & Time -->
						<div class="form-row two-col">
							<div class="form-field">
								<label class="form-label" for="appointment-date"><?php esc_html_e( 'Preferred Appointment Date', 'care-towards-cure' ); ?></label>
								<input
									type="date"
									id="appointment-date"
									name="appointment_date"
									class="form-input date-input"
									placeholder="MM/DD/YYYY"
								>
							</div>
							<div class="form-field">
								<label class="form-label" for="appointment-time"><?php esc_html_e( 'Preferred Appointment Time', 'care-towards-cure' ); ?></label>
								<input
									type="time"
									id="appointment-time"
									name="appointment_time"
									class="form-input time-input"
									placeholder="HH:MM"
								>
							</div>
						</div>

						<!-- Reason for Visit -->
						<div class="form-field">
							<label class="form-label" for="reason"><?php esc_html_e( 'Reason for Visit', 'care-towards-cure' ); ?></label>
							<textarea
								id="reason"
								name="reason"
								class="form-textarea"
								placeholder="<?php esc_attr_e( 'Briefly describe your symptoms or reason for the visit...', 'care-towards-cure' ); ?>"
							></textarea>
						</div>
					</form>
				</div>

				<!-- Modal Footer -->
				<div class="modal-footer">
					<button type="button" class="modal-btn modal-btn-cancel"><?php esc_html_e( 'Cancel', 'care-towards-cure' ); ?></button>
					<button type="submit" form="appointmentForm" class="modal-btn modal-btn-submit"><?php esc_html_e( 'Submit Inquiry', 'care-towards-cure' ); ?> ➤</button>
				</div>
			</div>
		</div>
	</main>

<?php
get_footer();
