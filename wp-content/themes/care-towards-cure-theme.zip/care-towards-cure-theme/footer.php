<?php
/**
 * The footer template
 *
 * Displays the site footer and closes HTML structure
 *
 * @package Care_Towards_Cure_Theme
 */

defined( 'ABSPATH' ) || exit;
?>

	<footer class="site-footer" role="contentinfo">
		<div class="container">
			<!-- Footer Content -->
			<div class="footer-content">
				<!-- Branding & Tagline -->
				<div class="footer-branding">
					<?php
					$footer_logo_name = get_theme_mod( 'care_footer_logo_name', get_bloginfo( 'name' ) );
					$footer_tagline   = get_theme_mod( 'care_footer_tagline', __( 'Dedicated to providing world-class medical care with compassion and integrity.', 'care-towards-cure' ) );
					?>
					<h2 class="footer-logo-name"><?php echo esc_html( $footer_logo_name ); ?></h2>
					<?php if ( $footer_tagline ) : ?>
						<p class="footer-tagline"><?php echo esc_html( $footer_tagline ); ?></p>
					<?php endif; ?>
				</div>

				<!-- Social Media Links -->
				<div class="footer-social">
					<h3 class="footer-social-title"><?php esc_html_e( 'Follow Us', 'care-towards-cure' ); ?></h3>
					<div class="social-links">
						<?php
						$social_links = array(
							'facebook'  => array( 'icon' => '📘', 'label' => 'Facebook', 'url' => get_theme_mod( 'care_social_facebook' ) ),
							'twitter'   => array( 'icon' => '𝕏', 'label' => 'Twitter', 'url' => get_theme_mod( 'care_social_twitter' ) ),
							'instagram' => array( 'icon' => '📷', 'label' => 'Instagram', 'url' => get_theme_mod( 'care_social_instagram' ) ),
							'linkedin'  => array( 'icon' => '🔗', 'label' => 'LinkedIn', 'url' => get_theme_mod( 'care_social_linkedin' ) ),
							'youtube'   => array( 'icon' => '▶', 'label' => 'YouTube', 'url' => get_theme_mod( 'care_social_youtube' ) ),
						);

						foreach ( $social_links as $platform => $details ) {
							if ( ! empty( $details['url'] ) ) {
								?>
								<a
									href="<?php echo esc_url( $details['url'] ); ?>"
									class="social-link"
									title="<?php echo esc_attr( $details['label'] ); ?>"
									target="_blank"
									rel="noopener noreferrer"
									aria-label="<?php echo esc_attr( $details['label'] ); ?>"
								>
									<?php echo esc_html( $details['icon'] ); ?>
								</a>
								<?php
							}
						}
						?>
					</div>
				</div>

				<!-- Contact Details -->
				<div class="footer-contact">
					<h3 class="footer-contact-title"><?php esc_html_e( 'Contact', 'care-towards-cure' ); ?></h3>
					<?php
					$footer_phone = get_theme_mod( 'care_footer_phone', '+91 9414311475' );
					$footer_email = get_theme_mod( 'care_footer_email', 'caretowardscure@gmail.com' );
					$footer_hours = get_theme_mod( 'care_footer_hours', '24/7 Available' );
					?>

					<?php if ( $footer_phone ) : ?>
						<div class="contact-item">
							<span class="contact-item-icon">📞</span>
							<p class="contact-item-text"><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $footer_phone ) ); ?>"><?php echo esc_html( $footer_phone ); ?></a></p>
						</div>
					<?php endif; ?>

					<?php if ( $footer_email ) : ?>
						<div class="contact-item">
							<span class="contact-item-icon">✉️</span>
							<p class="contact-item-text"><a href="mailto:<?php echo esc_attr( $footer_email ); ?>"><?php echo esc_html( $footer_email ); ?></a></p>
						</div>
					<?php endif; ?>

					<?php if ( $footer_hours ) : ?>
						<div class="contact-item">
							<span class="contact-item-icon">🕐</span>
							<p class="contact-item-text"><?php echo esc_html( $footer_hours ); ?></p>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<?php
				$footer_copyright = get_theme_mod( 'care_footer_copyright', sprintf( '&copy; %d %s. All rights reserved.', gmdate( 'Y' ), get_bloginfo( 'name' ) ) );
				?>
				<?php if ( $footer_copyright ) : ?>
					<p class="footer-copyright"><?php echo wp_kses_post( $footer_copyright ); ?></p>
				<?php endif; ?>

				<!-- Footer Links -->
				<nav class="footer-links" aria-label="<?php esc_attr_e( 'Footer Links', 'care-towards-cure' ); ?>">
					<?php
					wp_nav_menu( array(
						'theme_location' => 'footer',
						'fallback_cb'     => false,
						'depth'           => 1,
						'container'       => false,
						'items_wrap'      => '%3$s',
					) );
					?>
				</nav>
			</div>
		</div>
	</footer>

	<?php wp_footer(); ?>
</body>
</html>
