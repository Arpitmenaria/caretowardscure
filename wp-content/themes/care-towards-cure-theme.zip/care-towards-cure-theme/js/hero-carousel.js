/**
 * Care Towards Cure - Hero Carousel
 * Handles image carousel autoplay, navigation, and accessibility
 */

(function() {
	'use strict';

	/**
	 * Hero Carousel Class
	 */
	class HeroCarousel {
		constructor() {
			this.carousels = document.querySelectorAll('.hero-carousel');
			this.autoplayInterval = null;
			this.autoplayDelay = 5000; // 5 seconds

			if (this.carousels.length === 0) {
				return;
			}

			this.init();
		}

		/**
		 * Initialize carousel
		 */
		init() {
			this.carousels.forEach((carousel) => {
				const track = carousel.querySelector('.hero-carousel-track');
				const slides = carousel.querySelectorAll('.hero-carousel-slide');
				const dots = carousel.querySelectorAll('.hero-carousel-dot');
				const prevBtn = carousel.querySelector('.hero-carousel-arrow.prev');
				const nextBtn = carousel.querySelector('.hero-carousel-arrow.next');

				if (!track || slides.length === 0) {
					return;
				}

				const carouselState = {
					track: track,
					slides: slides,
					dots: dots,
					prevBtn: prevBtn,
					nextBtn: nextBtn,
					currentIndex: 0,
					slideCount: slides.length,
					transitioning: false,
				};

				// Setup carousel
				this.setupCarousel(carousel, carouselState);

				// Event listeners
				if (prevBtn) {
					prevBtn.addEventListener('click', () => this.prevSlide(carousel, carouselState));
				}
				if (nextBtn) {
					nextBtn.addEventListener('click', () => this.nextSlide(carousel, carouselState));
				}

				// Dot navigation
				dots.forEach((dot, index) => {
					dot.addEventListener('click', () => this.goToSlide(carousel, carouselState, index));
					dot.setAttribute('aria-label', `Go to slide ${index + 1}`);
				});

				// Keyboard navigation
				carousel.addEventListener('keydown', (e) => this.handleKeyboard(e, carousel, carouselState));

				// Auto-play
				this.startAutoplay(carousel, carouselState);

				// Pause auto-play on user interaction
				carousel.addEventListener('mouseenter', () => this.pauseAutoplay());
				carousel.addEventListener('mouseleave', () => this.startAutoplay(carousel, carouselState));

				// Touch support
				let touchStartX = 0;
				carousel.addEventListener('touchstart', (e) => {
					touchStartX = e.touches[0].clientX;
				});
				carousel.addEventListener('touchend', (e) => {
					const touchEndX = e.changedTouches[0].clientX;
					const diff = touchStartX - touchEndX;

					if (Math.abs(diff) > 50) {
						diff > 0 ? this.nextSlide(carousel, carouselState) : this.prevSlide(carousel, carouselState);
					}
				});

				// Store state on carousel element
				carousel.carouselState = carouselState;
			});
		}

		/**
		 * Setup carousel initial state
		 */
		setupCarousel(carousel, state) {
			if (state.slideCount > 0) {
				state.dots[0].classList.add('active');
				this.updateSlidePosition(state);
			}

			// Set ARIA attributes
			state.slides.forEach((slide, index) => {
				slide.setAttribute('role', 'group');
				slide.setAttribute('aria-label', `Slide ${index + 1} of ${state.slideCount}`);
			});

			state.track.setAttribute('role', 'region');
			state.track.setAttribute('aria-label', 'Image carousel');
		}

		/**
		 * Update slide position visually
		 */
		updateSlidePosition(state) {
			const offset = -state.currentIndex * 100;
			state.track.style.transform = `translateX(${offset}%)`;
		}

		/**
		 * Go to specific slide
		 */
		goToSlide(carousel, state, index) {
			if (state.transitioning || index === state.currentIndex) {
				return;
			}

			state.transitioning = true;
			state.currentIndex = index;

			this.updateSlidePosition(state);

			// Update dots
			state.dots.forEach((dot, i) => {
				dot.classList.toggle('active', i === index);
			});

			setTimeout(() => {
				state.transitioning = false;
			}, 500);
		}

		/**
		 * Next slide
		 */
		nextSlide(carousel, state) {
			const nextIndex = (state.currentIndex + 1) % state.slideCount;
			this.goToSlide(carousel, state, nextIndex);
		}

		/**
		 * Previous slide
		 */
		prevSlide(carousel, state) {
			const prevIndex = (state.currentIndex - 1 + state.slideCount) % state.slideCount;
			this.goToSlide(carousel, state, prevIndex);
		}

		/**
		 * Handle keyboard navigation
		 */
		handleKeyboard(e, carousel, state) {
			if (e.key === 'ArrowRight') {
				e.preventDefault();
				this.nextSlide(carousel, state);
			} else if (e.key === 'ArrowLeft') {
				e.preventDefault();
				this.prevSlide(carousel, state);
			}
		}

		/**
		 * Start autoplay
		 */
		startAutoplay(carousel, state) {
			if (state.slideCount <= 1) {
				return;
			}

			this.pauseAutoplay();

			this.autoplayInterval = setInterval(() => {
				this.nextSlide(carousel, state);
			}, this.autoplayDelay);
		}

		/**
		 * Pause autoplay
		 */
		pauseAutoplay() {
			if (this.autoplayInterval) {
				clearInterval(this.autoplayInterval);
				this.autoplayInterval = null;
			}
		}
	}

	/**
	 * Initialize on DOM ready
	 */
	function init() {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', () => {
				new HeroCarousel();
			});
		} else {
			new HeroCarousel();
		}
	}

	init();
})();
