/**
 * Care Towards Cure - Gallery Horizontal Scroll
 * Handles scrolling navigation for gallery/facilities cards
 */

(function() {
	'use strict';

	/**
	 * Initialize gallery scroll
	 */
	function initGalleryScroll() {
		const scrollContainer = document.querySelector('.gallery-grid');
		const prevBtn = document.querySelector('.gallery-scroll-btn.prev');
		const nextBtn = document.querySelector('.gallery-scroll-btn.next');

		if (!scrollContainer || !prevBtn || !nextBtn) {
			return;
		}

		// Scroll amount (full container width)
		const getScrollAmount = () => {
			return scrollContainer.clientWidth;
		};

		// Scroll left
		prevBtn.addEventListener('click', () => {
			scrollContainer.scrollBy({
				left: -getScrollAmount(),
				behavior: 'smooth'
			});
		});

		// Scroll right
		nextBtn.addEventListener('click', () => {
			scrollContainer.scrollBy({
				left: getScrollAmount(),
				behavior: 'smooth'
			});
		});

		// Handle keyboard navigation
		scrollContainer.addEventListener('keydown', (e) => {
			if (e.key === 'ArrowLeft') {
				e.preventDefault();
				prevBtn.click();
			} else if (e.key === 'ArrowRight') {
				e.preventDefault();
				nextBtn.click();
			}
		});

		// Update button visibility based on scroll position
		const updateButtonState = () => {
			const isAtStart = scrollContainer.scrollLeft <= 10;
			const isAtEnd = scrollContainer.scrollLeft >=
				scrollContainer.scrollWidth - scrollContainer.clientWidth - 10;

			prevBtn.style.opacity = isAtStart ? '0.5' : '1';
			prevBtn.style.cursor = isAtStart ? 'not-allowed' : 'pointer';
			prevBtn.disabled = isAtStart;

			nextBtn.style.opacity = isAtEnd ? '0.5' : '1';
			nextBtn.style.cursor = isAtEnd ? 'not-allowed' : 'pointer';
			nextBtn.disabled = isAtEnd;
		};

		scrollContainer.addEventListener('scroll', updateButtonState, { passive: true });
		window.addEventListener('resize', updateButtonState);
		updateButtonState();
	}

	/**
	 * Initialize on DOM ready
	 */
	function init() {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', initGalleryScroll);
		} else {
			initGalleryScroll();
		}
	}

	init();
})();
